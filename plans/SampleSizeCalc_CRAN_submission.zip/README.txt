SampleSizeCalc 3.1.1 — CRAN submission materials

Upload SampleSizeCalc_3.1.1.tar.gz to the CRAN submission form:
https://cran.r-project.org/submit.html

Use cran-comments.md for the optional submission comment. The ZIP file is
only a convenient bundle of review materials; the source tarball is the
file to upload as the package.

The included source tarball completed full R CMD check --as-cran runs on:
- Windows 11, R 4.6.1;
- Windows 11, R-devel 2026-11-03 r90835;
- Ubuntu 24.04.4 under WSL2, R 4.6.1.

All three runs finished with 0 errors, 0 warnings, and 1 New submission note.
The check logs are included under checks/. CHECKSUMS.sha256 identifies the
exact source archive that was checked.

After installing the package, load it with:
  library(SampleSizeCalc)

The source repository and existing website addresses remain valid. The
renamed vignette articles use overview, clinical-guide-en and clinical-guide-zh;
compatibility pages preserve the existing article addresses.

The documentation website and manuscript materials have been refreshed in
the project. No formal CRAN submission or website deployment was performed.
