## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7.2,
  fig.height = 4.8,
  message = TRUE,
  warning = FALSE
)

library(SampleSizeCalc)
library(ggplot2)

## ----rct-mean-en--------------------------------------------------------------
res_1_1 <- calculate("rct", "test", "mean", mean1 = 10, mean2 = 12, sd = 3, alpha = 0.05, power = 0.8)
print(res_1_1)

## ----report-fields-en, eval = FALSE-------------------------------------------
# res_1_1$formula
# cat(res_1_1$formula_latex)
# cat(res_1_1$calculation_steps, sep = "\n")
# cat(res_1_1$reference)

## ----rct-prop-en--------------------------------------------------------------
res_1_2 <- calculate("rct", "test", "proportion", p1 = 0.85, p2 = 0.70, alpha = 0.05, power = 0.8)
print(res_1_2)

## ----rct-surv-en--------------------------------------------------------------
res_1_3 <- calculate("rct", "test", "survival", hr = 0.70, pE = 0.50, alpha = 0.05, power = 0.8)
print(res_1_3)

## ----rct-ni-mean-en-----------------------------------------------------------
res_1_4 <- calculate("rct", "noninferiority", "mean", mean1 = 10, mean2 = 9.5, sd = 3, margin = 1, alpha = 0.05, power = 0.8)
print(res_1_4)

## ----rct-ni-prop-en-----------------------------------------------------------
res_1_5 <- calculate("rct", "noninferiority", "proportion", p1 = 0.85, p2 = 0.85, margin = 0.05, alpha = 0.05, power = 0.8)
print(res_1_5)

## ----rct-sup-mean-en----------------------------------------------------------
res_1_6 <- calculate("rct", "superiority", "mean", mean1 = 12, mean2 = 10, sd = 3, margin = 1, alpha = 0.05, power = 0.8)
print(res_1_6)

## ----rct-sup-prop-en----------------------------------------------------------
res_1_7 <- calculate("rct", "superiority", "proportion", p1 = 0.30, p2 = 0.20, margin = 0.05, alpha = 0.05, power = 0.8)
print(res_1_7)

## ----rct-equiv-mean-en--------------------------------------------------------
res_1_8 <- calculate("rct", "equivalence", "mean", mean1 = 10, mean2 = 10.2, sd = 3, margin = 1, alpha = 0.05, power = 0.8)
print(res_1_8)

## ----rct-equiv-prop-en--------------------------------------------------------
res_1_9 <- calculate("rct", "equivalence", "proportion", p1 = 0.50, p2 = 0.52, margin = 0.10, alpha = 0.05, power = 0.8)
print(res_1_9)

## ----paired-mean-en-----------------------------------------------------------
res_2_1 <- calculate("paired", "test", "mean", meanDiff = 2, sdDiff = 3, alpha = 0.05, power = 0.8)
print(res_2_1)

## ----paired-prop-en-----------------------------------------------------------
res_2_2 <- calculate("paired", "test", "proportion", p1 = 0.80, p2 = 0.60, psi = 0.25, alpha = 0.05, power = 0.8)
print(res_2_2)

## ----singlearm-mean-en--------------------------------------------------------
res_2_3 <- calculate("rctSingleArm", "test", "mean", mu0 = 10, mu1 = 12, sigma = 3, alpha = 0.05, power = 0.8)
print(res_2_3)

## ----singlearm-prop-en--------------------------------------------------------
res_2_4 <- calculate("rctSingleArm", "test", "proportion", p0 = 0.70, p1 = 0.80, alpha = 0.05, power = 0.8)
print(res_2_4)

## ----simon-opt-en-------------------------------------------------------------
res_2_5 <- calculate("singleArmPhaseII", "test", "proportion", p0 = 0.10, p1 = 0.30, alpha = 0.05, power = 0.8, optimizer = "optimal")
print(res_2_5)

## ----simon-mini-en------------------------------------------------------------
res_2_6 <- calculate("singleArmPhaseII", "test", "proportion", p0 = 0.10, p1 = 0.30, alpha = 0.05, power = 0.8, optimizer = "minimax")
print(res_2_6)

## ----ahern-en-----------------------------------------------------------------
res_2_7 <- SampleSizeCalc:::calculate_ahern(p0 = 0.10, p1 = 0.30, alpha = 0.05, power = 0.8)
print(res_2_7)

## ----crossover-en-------------------------------------------------------------
res_2_8 <- calculate("crossover", "test", "mean", delta = 2, sigma_within = 3, alpha = 0.05, power = 0.8)
print(res_2_8)

## ----be-en--------------------------------------------------------------------
res_2_9 <- calculate("bioequivalence", cv = 0.25, theta0 = 1.0, alpha = 0.05, power = 0.8)
print(res_2_9)

## ----cohort-prop-en-----------------------------------------------------------
res_3_1 <- calculate("cohort", "test", "proportion", p0 = 0.20, p1 = 0.30, ratio = 1, dropout = 0.10, alpha = 0.05, power = 0.8)
print(res_3_1)

## ----cohort-rate-en-----------------------------------------------------------
res_3_2 <- calculate("cohort", "test", "rate", rate0 = 0.10, rate1 = 0.20, ratio = 1, alpha = 0.05, power = 0.8)
print(res_3_2)

## ----cc-en--------------------------------------------------------------------
res_3_3 <- calculate("caseControl", p0 = 0.30, OR = 2.0, m = 1, alpha = 0.05, power = 0.8)
print(res_3_3)

## ----cc-matched-en------------------------------------------------------------
res_3_4 <- calculate("caseControlMatched", p0 = 0.30, OR = 2.0, alpha = 0.05, power = 0.8)
print(res_3_4)

## ----crosstab-en--------------------------------------------------------------
res_3_5 <- calculate("crosstab", p0 = 0.20, p1 = 0.30, alpha = 0.05, power = 0.8)
print(res_3_5)

## ----single-prop-en-----------------------------------------------------------
res_4_1 <- calculate("singleProportion", p = 0.10, precision = 0.02, alpha = 0.05)
print(res_4_1)

## ----single-mean-en-----------------------------------------------------------
res_4_2 <- calculate("singleMean", sigma = 10, precision = 2, alpha = 0.05)
print(res_4_2)

## ----single-cor-en------------------------------------------------------------
res_4_3 <- calculate("singleCorrelation", r = 0.50, precision = 0.10, alpha = 0.05)
print(res_4_3)

## ----diag-acc-en--------------------------------------------------------------
res_5_1 <- calculate("diagAccuracy", "estimate", "proportion", prob = 0.85, d = 0.05, prevalence = 0.20, alpha = 0.05)
print(res_5_1)

## ----diag-test-asym-en--------------------------------------------------------
res_5_2 <- calculate("diagAccuracy", "test", "proportion", prob = 0.85, p0 = 0.70, prevalence = 0.20, alpha = 0.05, power = 0.8)
print(res_5_2)

## ----diag-test-exact-en-------------------------------------------------------
res_5_3 <- calculate("diagAccuracy", "test", "proportion", prob = 0.85, p0 = 0.70, prevalence = 0.20, method = "exact", alpha = 0.05, power = 0.8)
print(res_5_3)

## ----diag-dual-en-------------------------------------------------------------
res_5_4 <- calculate("diagAccuracy", "test", "proportion", prob = 0.90, p0 = 0.80, prob_spec = 0.85, p0_spec = 0.75, prevalence = 0.40, dual = TRUE)
print(res_5_4)

## ----diag-compare-unpaired-en-------------------------------------------------
res_5_5 <- calculate("diagAccuracyCompare", "test", "proportion", p1 = 0.85, p2 = 0.75, prevalence = 0.20, paired = FALSE, alpha = 0.05, power = 0.8)
print(res_5_5)

## ----diag-compare-paired-en---------------------------------------------------
res_5_6 <- calculate("diagAccuracyCompare", "test", "proportion", p1 = 0.85, p2 = 0.75, prevalence = 0.20, paired = TRUE, psi = 0.10, alpha = 0.05, power = 0.8)
print(res_5_6)

## ----diag-compare-ni-en-------------------------------------------------------
res_5_7 <- calculate("diagAccuracyCompare", "noninferiority", "proportion", p1 = 0.90, p2 = 0.88, margin = 0.05, prevalence = 0.30, alpha = 0.05, power = 0.8)
print(res_5_7)

## ----diag-compare-equiv-en----------------------------------------------------
res_5_8 <- calculate("diagAccuracyCompare", "equivalence", "proportion", p1 = 0.90, p2 = 0.89, margin = 0.05, prevalence = 0.30, alpha = 0.05, power = 0.8)
print(res_5_8)

## ----diag-auc-est-en----------------------------------------------------------
res_5_9 <- calculate("diagAUC", "estimate", "auc", auc = 0.80, d = 0.10, ratio = 1, var_method = "binormal", alpha = 0.05)
print(res_5_9)

## ----diag-auc-test-en---------------------------------------------------------
res_5_10 <- calculate("diagAUC", "test", "auc", auc = 0.80, auc0 = 0.70, prevalence = 0.30, alpha = 0.05, power = 0.8)
print(res_5_10)

## ----diag-auc-compare-en------------------------------------------------------
res_5_11 <- calculate("diagAUCCompare", "test", "auc", auc1 = 0.80, auc2 = 0.70, r = 0.50, prevalence = 0.30, alpha = 0.05, power = 0.8)
print(res_5_11)

## ----diag-auc-ni-en-----------------------------------------------------------
res_5_12 <- calculate("diagAUCCompare", "noninferiority", "auc", auc1 = 0.85, auc2 = 0.82, r = 0.50, margin = 0.05, alpha = 0.05, power = 0.8)
print(res_5_12)

## ----diag-auc-equiv-en--------------------------------------------------------
res_5_13 <- calculate("diagAUCCompare", "equivalence", "auc", auc1 = 0.85, auc2 = 0.84, r = 0.50, margin = 0.05, alpha = 0.05, power = 0.8)
print(res_5_13)

## ----diag-lr-en---------------------------------------------------------------
res_5_14 <- calculate("diagLR", "estimate", "lr", sens = 0.90, spec = 0.50, target_lr = 0.40, lr_type = "negative", alpha = 0.05)
print(res_5_14)

## ----screen-req-en------------------------------------------------------------
safe_n <- screen_required(n = 196, prevalence = 0.20, beta = 0.10)
cat("Average screening target: 980; 90% guaranteed enrollment target:", safe_n, "\n")

## ----mrmc-en------------------------------------------------------------------
res_5_16 <- mrmc_power(n = 50, J = 8, delta = 0.10, sigma_b2 = 0.00123, sigma_w2 = 0.00087, sigma_c2 = 0.00196, rho1 = 0.50, rho2 = 0.30, rho3 = 0.25, rho_b = 0.75)
print(res_5_16)

## ----cluster-mean-en----------------------------------------------------------
res_6_1 <- calculate("clusterRCT", "test", "mean", mean1 = 10, mean2 = 12, sd = 3, icc = 0.05, cluster_size = 20, alpha = 0.05, power = 0.8)
print(res_6_1)

## ----cluster-prop-en----------------------------------------------------------
res_6_2 <- calculate("clusterRCT", "test", "proportion", p1 = 0.30, p2 = 0.20, icc = 0.05, cluster_size = 20, alpha = 0.05, power = 0.8)
print(res_6_2)

## ----stepped-wedge-en---------------------------------------------------------
res_6_3 <- calculate("steppedWedge", "test", "mean", theta = -0.016, tau2 = 2.25e-4, sigma2_ind = 0.0475, m = 100, n_clusters = 24, clusters_per_step = 6, alpha = 0.05)
print(res_6_3)

## ----ordinal-en---------------------------------------------------------------
res_6_4 <- calculate("twoOrdinal", "test", "ordinal", or = 1.5, prop_bar = c(0.2, 0.5, 0.3), alpha = 0.05, power = 0.8)
print(res_6_4)

## ----riley-bin-en-------------------------------------------------------------
res_6_5 <- calculate("predictiveModel", "plan", "binary", prev = 0.30, n_parameters = 10, r2_cs = 0.10, shrinkage = 0.90, precision_delta = 0.05, alpha = 0.05)
print(res_6_5)

## ----riley-rate-en------------------------------------------------------------
res_6_6 <- calculate("predictiveModel", "plan", "rate", rate = 0.10, timepoint = 10, precision_delta = 0.05, alpha = 0.05)
print(res_6_6)

## ----epv-en-------------------------------------------------------------------
res_6_7 <- calculate("predictiveModel", "plan", "events", n_parameters = 10, epv = 10, event_prevalence = 0.30)
print(res_6_7)

## ----kappa-est-en-------------------------------------------------------------
res_6_8 <- calculate("kappa", "estimate", "proportion", pi1 = 0.50, pi2 = 0.50, kappa = 0.70, d = 0.10, alpha = 0.05)
print(res_6_8)

## ----kappa-test-en------------------------------------------------------------
res_6_9 <- calculate("kappa", "test", "proportion", pi1 = 0.50, pi2 = 0.50, kappa1 = 0.70, kappa2 = 0.50, alpha = 0.05, power = 0.8)
print(res_6_9)

## ----its-en-------------------------------------------------------------------
res_6_10 <- calculate("its", "test", "rate", effect_sd = 2, n_pre = 12, n_post = 12, rho = 0.3, alpha = 0.05, power = 0.8)
print(res_6_10)

## ----rct-planning-grid-en-----------------------------------------------------
rct_plan <- data.frame(
  scenario = c("Base case", "Higher variability", "Smaller difference", "Both changes"),
  mean2 = c(12, 12, 11.5, 11.5),
  sd = c(3, 4, 3, 4)
)
rct_plan$complete <- vapply(seq_len(nrow(rct_plan)), function(i) {
  calculate("rct", "test", "mean",
    mean1 = 10, mean2 = rct_plan$mean2[i], sd = rct_plan$sd[i]
  )$n_per_group
}, numeric(1))
rct_plan$recruit <- ceiling(rct_plan$complete / 0.9)
knitr::kable(rct_plan,
  col.names = c("Scenario", "Study mean", "Change SD", "Complete/arm", "Recruit/arm")
)

## ----diagnostic-planning-grid-en----------------------------------------------
diag_plan <- data.frame(prevalence = c(0.10, 0.20, 0.30))
diag_plan$expected <- ceiling(
  res_5_1$target_state_cases_needed / diag_plan$prevalence
)
diag_plan$guaranteed <- vapply(diag_plan$prevalence, function(prev) {
  screen_required(res_5_1$target_state_cases_needed, prev, beta = 0.10)
}, numeric(1))
knitr::kable(diag_plan,
  col.names = c("Prevalence", "Expectation-based total", "90% yield requirement")
)

## ----summary-demo-en----------------------------------------------------------
summary(res_1_1)

## ----plot-power-en------------------------------------------------------------
plot(res_1_1, type = "power")

## ----plot-effect-en-----------------------------------------------------------
plot(res_1_1, type = "sample_size")

