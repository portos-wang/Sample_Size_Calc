## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(SampleSizeCalc)

## ----default-report-----------------------------------------------------------
res <- calculate("rct", "test", "mean", mean1 = 10, mean2 = 12, sd = 3)
print(res)

## ----plain-text-formula-------------------------------------------------------
cat(res$formula, "\n")

## ----latex-source-------------------------------------------------------------
cat(res$formula_latex, "\n")

## ----calculation-steps--------------------------------------------------------
cat(res$calculation_steps, sep = "\n")

## ----references---------------------------------------------------------------
cat(res$reference, "\n")

## ----rendered-formula, results = "asis"---------------------------------------
cat(res$formula_latex, "\n\n")

## ----summary-report-----------------------------------------------------------
summary(res)

## ----legacy-report------------------------------------------------------------
legacy_res <- sample_size_calculator(
  "twoProportions", p1 = 0.85, p2 = 0.70
)
print(legacy_res)

## ----save-report, eval = FALSE------------------------------------------------
# report <- c(
#   res$design_type,
#   paste("Sample size per group:", res$n_per_group),
#   paste("Total sample size:", res$total_n),
#   "", "Formula (plain text)", res$formula,
#   "", "Formula (LaTeX)", res$formula_latex,
#   "", "Calculation process", res$calculation_steps,
#   "", "Reference", res$reference
# )
# writeLines(enc2utf8(report), "sample-size-report.txt", useBytes = TRUE)

