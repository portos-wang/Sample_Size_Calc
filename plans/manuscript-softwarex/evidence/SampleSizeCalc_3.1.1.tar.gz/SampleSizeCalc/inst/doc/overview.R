## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 4.5,
  message = TRUE,
  warning = FALSE
)

library(SampleSizeCalc)
library(ggplot2)

## ----three-axis-mean----------------------------------------------------------
calculate("rct", "test", "mean", mean1 = 10, mean2 = 12, sd = 3)

## ----three-axis-cohort--------------------------------------------------------
calculate("cohort", "test", "proportion", p0 = 0.20, p1 = 0.30, dropout = 0.10)

## ----three-axis-auc-----------------------------------------------------------
calculate("diagAUC", "estimate", "auc",
  auc = 0.80, d = 0.10,
  ratio = 1, var_method = "binormal"
)

## ----install, eval = FALSE----------------------------------------------------
# # Install from GitHub
# devtools::install_github("portos-wang/Sample_Size_Calc")
# 
# # Or install from local source
# devtools::install_local("path/to/1_sample_size_determination")

## ----two-means-example--------------------------------------------------------
result <- sample_size_calculator(
  design = "twoMeans",
  mean1 = 10, # Control group mean (mmHg reduction)
  mean2 = 12, # Treatment group mean (mmHg reduction)
  sd = 3, # Common standard deviation
  alpha = 0.05, # Significance level
  power = 0.8 # Target power (80%)
)

print(result)

## ----paired-means-example-----------------------------------------------------
result <- sample_size_calculator(
  design = "pairedMeans",
  meanDiff = 2.5, # Mean difference (post-pre)
  sdDiff = 4.0, # SD of differences
  alpha = 0.05,
  power = 0.9
)

print(result)

## ----two-proportions-example--------------------------------------------------
result <- sample_size_calculator(
  design = "twoProportions",
  p1 = 0.30, # Control response rate
  p2 = 0.45, # Treatment response rate
  alpha = 0.05,
  power = 0.8
)

print(result)

## ----survival-example---------------------------------------------------------
result <- sample_size_calculator(
  design = "survival",
  hr = 0.70, # Hazard ratio (treatment vs. control)
  pE = 0.50, # Proportion in experimental group (1:1 randomization)
  alpha = 0.05,
  power = 0.8
)

print(result)

## ----non-inferiority-means-example--------------------------------------------
result <- sample_size_calculator(
  design = "nonInferiorityMeans",
  mean1 = 8.0, # New treatment mean
  mean2 = 8.5, # Standard treatment mean
  sd = 2.0, # Common SD
  margin = 1.0, # Non-inferiority margin (Δ)
  alpha = 0.025, # One-sided test
  power = 0.9
)

print(result)

## ----superiority-means-example------------------------------------------------
result <- sample_size_calculator(
  design = "superiorityMeans",
  mean1 = 12.0, # New treatment mean (better)
  mean2 = 10.0, # Standard treatment mean
  sd = 2.5, # Common SD
  margin = 0.5, # Minimal clinically important difference
  alpha = 0.025, # One-sided test
  power = 0.85
)

print(result)

## ----equivalence-means-example------------------------------------------------
result <- sample_size_calculator(
  design = "equivalenceMeans",
  mean1 = 100, # Test mean
  mean2 = 102, # Reference mean
  sd = 5, # Common SD
  margin = 5, # Equivalence margin (±5 units)
  alpha = 0.05,
  power = 0.8
)

print(result)

## ----diagnostic-accuracy-example----------------------------------------------
result <- sample_size_calculator(
  design = "diagnosticAccuracySingle",
  prob = 0.85, # Expected sensitivity
  d = 0.05, # Desired precision (±5%)
  prevalence = 0.20, # Disease prevalence
  alpha = 0.05
)

print(result)

## ----auc-single-example-------------------------------------------------------
result <- sample_size_calculator(
  design = "auc_single",
  auc = 0.80, # Expected AUC
  d = 0.05, # Half-width of CI (±0.10 total)
  prevalence = 0.30,
  alpha = 0.05
)

print(result)

## ----auc-comparison-example---------------------------------------------------
result <- sample_size_calculator(
  design = "aucComparison",
  auc1 = 0.85, # Test 1 AUC
  auc2 = 0.80, # Test 2 AUC
  r = 0.6, # Correlation between AUCs
  prevalence = 0.25,
  alpha = 0.05,
  power = 0.8
)

print(result)

## ----case-control-example-----------------------------------------------------
result <- sample_size_calculator(
  design = "caseControl",
  p0 = 0.30, # Exposure rate in controls
  OR = 2.5, # Target odds ratio
  m = 1, # Controls per case (unmatched group ratio)
  alpha = 0.05,
  power = 0.8
)

print(result)

## ----plot-power, fig.width = 7, fig.height = 5--------------------------------
result <- sample_size_calculator(
  "twoMeans",
  mean1 = 10,
  mean2 = 12,
  sd = 3,
  alpha = 0.05,
  power = 0.8
)

# Plot sample size vs. power
plot(result, type = "power")

## ----plot-sample-size, fig.width = 7, fig.height = 5--------------------------
# Plot sample size vs. effect size ratio
plot(result, type = "sample_size")

## ----summary-example----------------------------------------------------------
result <- sample_size_calculator(
  "survival",
  hr = 0.70,
  alpha = 0.05,
  power = 0.8
)

summary(result)

## ----report-fields-overview, eval = FALSE-------------------------------------
# result$formula
# cat(result$formula_latex)
# cat(result$calculation_steps, sep = "\n")
# cat(result$reference)

## ----best-practice-1, eval = FALSE--------------------------------------------
# # DON'T: Use unrealistic effect sizes
# sample_size_calculator("twoMeans", mean1 = 10, mean2 = 15, sd = 3)
# 
# # DO: Use effect sizes from literature or pilot studies
# # From meta-analysis: standardized mean difference = 0.5
# smd <- 0.5
# sd <- 3
# mean_diff <- smd * sd # 1.5
# sample_size_calculator("twoMeans", mean1 = 10, mean2 = 10 + mean_diff, sd = sd)

## ----best-practice-2, eval = FALSE--------------------------------------------
# # Calculate required sample size
# result <- sample_size_calculator("twoMeans", mean1 = 10, mean2 = 12, sd = 3, power = 0.8)
# n_per_group <- result$n_per_group
# 
# # Adjust for 20% dropout
# dropout_rate <- 0.20
# n_adjusted <- ceiling(n_per_group / (1 - dropout_rate))

## ----best-practice-3, eval = FALSE--------------------------------------------
# # Conservative scenario (smaller effect)
# result1 <- sample_size_calculator("twoMeans", mean1 = 10, mean2 = 11, sd = 3)
# 
# # Optimistic scenario (larger effect)
# result2 <- sample_size_calculator("twoMeans", mean1 = 10, mean2 = 13, sd = 3)

## ----pitfall-1, eval = FALSE--------------------------------------------------
# # WRONG: Using independent formula for paired data
# sample_size_calculator("twoMeans", mean1 = 10, mean2 = 12, sd = 3)
# 
# # CORRECT: Using paired design
# sample_size_calculator("pairedMeans", meanDiff = 2, sdDiff = 4)

## ----pitfall-2, eval = FALSE--------------------------------------------------
# # Schoenfeld formula gives EVENTS, not sample size
# result <- sample_size_calculator("survival", hr = 0.7, power = 0.8)
# events_needed <- result$target_events_needed
# 
# # Convert to sample size based on event rate
# event_rate <- 0.50 # 50% of subjects experience event
# total_sample <- ceiling(events_needed / event_rate)

## ----pitfall-3, eval = FALSE--------------------------------------------------
# # WRONG: Using two-sided α for non-inferiority
# sample_size_calculator("nonInferiorityMeans",
#   mean1 = 8, mean2 = 8.5,
#   sd = 2, margin = 1, alpha = 0.05
# )
# 
# # CORRECT: Using one-sided α
# sample_size_calculator("nonInferiorityMeans",
#   mean1 = 8, mean2 = 8.5,
#   sd = 2, margin = 1, alpha = 0.025
# )

